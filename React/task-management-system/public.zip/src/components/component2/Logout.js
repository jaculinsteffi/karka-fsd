import React from 'react'
import AdminHome from './AdminHome'

const Logout = () => {
  return (
    <div>
      <AdminHome/>
    </div>
  )
}

export default Logout
